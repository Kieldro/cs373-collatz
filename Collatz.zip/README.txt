Course Name: CS 373
Unique: 91055
First Name: Ian
Last Name: Buitrago
EID: ib
CS Username: keo
GitHub ID: Kieldro
GitHub Repository Name: cs373-collatz
Estimated number of hours: 10
Actual    number of hours: 12
Comments:
questions:
* What does chmod ugo+x RunCollatz.py do?
* tab vs 2 space indention
* don't submit java files?
* convention/style
* failure test is a test that always fail eg x = 0?
* is 8 1 allowed as input?
* global variables bad?
* git mv f1 f2
* how does hashbang work?

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.
